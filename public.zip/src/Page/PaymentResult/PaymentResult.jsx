import React, { Fragment } from "react";
import styled from "./PaymentResult.module.css";


export const PaymentResult = () =>{
    return ( 
        <Fragment>

            <h1>نتیجه پرداخت</h1>
        </Fragment>
     );
}

