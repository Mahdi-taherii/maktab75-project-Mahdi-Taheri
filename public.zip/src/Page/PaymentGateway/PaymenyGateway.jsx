import React, { Fragment } from "react";
import styled from "./PaymenyGateway.module.css";

export const PaymenyGateway = () => {
    return ( 
        <Fragment>

            <h1>در گاه پرداخت</h1>
        </Fragment>
     );
}

export default PaymenyGateway;