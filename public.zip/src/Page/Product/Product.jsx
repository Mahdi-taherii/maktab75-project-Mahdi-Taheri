import React, { Fragment } from "react";
import styled from "./Product.module.css";
import Header from "../../layout/Header/Header";
import Footer from "../../layout/Footer/Footer";

export const Product = () => {
    return ( 
        <Fragment>
            <Header/>
                <h1>صحفه خرید محصول</h1>

            <Footer/>

        </Fragment>
     );
}

