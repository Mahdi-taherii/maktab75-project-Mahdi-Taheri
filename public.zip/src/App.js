import './App.css';
import HandleRoutes from './routes/index.routes';


function App() {
  return (
    <div className="App">
     <HandleRoutes/>
    </div>
  );
}

export default App;
