export const PATHS = {
    HOME : "/",
    HOME_PAGE:"/HomePage",
    CART :"/Cart" ,
    FINAL_LEVEL:"/FinalLevel",
    LIST_PRODUCT:"/ListProduct",
    LOGIN_ADMIN:"/LoginAdmin",
    PRICES:"/Prices",
    ORDER:"/Order",
    GATEWAY:"/Gateway",
    RESULT:"/Result" ,
    PRODUCT:"/Product" ,
    MANAGEMENT:"/Management"
}